


vim.cmd([[
let g:context_enabled = 1
" disabling add mapping for now
let g:context_add_mappings = 0
let g:context_filetype_blacklist = ['*.jl', '*.ts', '*.js']

]])
