
vim.api.nvim_set_keymap('n','<leader>m',':Glow<CR>',{noremap = true, silent = true})
