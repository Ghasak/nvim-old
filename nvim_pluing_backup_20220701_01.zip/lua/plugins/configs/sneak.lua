

local M = {}

M.sneakSetup = function()


vim.cmd([[
" =============================================================================
"
"              ░██████╗███╗░░██╗███████╗░█████╗░██╗░░██╗
"              ██╔════╝████╗░██║██╔════╝██╔══██╗██║░██╔╝
"              ╚█████╗░██╔██╗██║█████╗░░███████║█████═╝░
"              ░╚═══██╗██║╚████║██╔══╝░░██╔══██║██╔═██╗░
"              ██████╔╝██║░╚███║███████╗██║░░██║██║░╚██╗
"              ╚═════╝░╚═╝░░╚══╝╚══════╝╚═╝░░╚═╝╚═╝░░╚═╝
"              Source: https://github.com/justinmk/vim-sneak
" =============================================================================
let g:sneak#label = 1
" case insensitive sneak
let g:sneak#use_ic_scs = 1
" immediately move to the next instance of search, if you move the cursor sneak is back to default behavior
let g:sneak#s_next = 1
" remap so I can use , and ; with f and t
map gs <Plug>Sneak_,<CR>
map gS <Plug>Sneak_;<CR>
" Change the colors
"highlight Sneak guifg=black guibg=#00C7DF ctermfg=black ctermbg=cyan
"highlight SneakScope guifg=red guibg=yellow ctermfg=red ctermbg=yellow
" Cool prompts
"let g:sneak#prompt = '    '
"let g:sneak#prompt = '  ﯒  '

"let g:sneak#prompt = '  '
let g:sneak#prompt = '  '
"let g:sneak#prompt = '  '
" I like quickscope better for this since it keeps me in the scope of a single line
" map f <Plug>Sneak_f
" map F <Plug>Sneak_F
" map t <Plug>Sneak_t
" map T <Plug>Sneak_T
]])







end


return M
